$(document).ready(function(){ 	
						   
						   
	// radius Box
	$('.menu_nav ul li a').css({"border-radius": "15px", "-moz-border-radius":"15px", "-webkit-border-radius":"15px"});
	// end radius Box
	 
});	
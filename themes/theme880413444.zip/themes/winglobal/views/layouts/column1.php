<?php $this->beginContent('//layouts/main'); ?>
<div class="content">
    <div class="content_resize">
        <div class="mainbar">
			<?php echo $content; ?>
		</div><!-- content -->
    </div>
    
    <div class="clr"></div>
</div>
<?php $this->endContent(); ?>
